#include <iostream> 

#include <fstream> 

#include <string.h> 

#include <string> 

#include <list> 

#include "Customer.h" 

#include <stack> 

using namespace std; 

class Movie 

{ 

private: 

int movie_id; 

string movieTitle; 

string genre; 

string production; 

int numberOfCopies = 0; 

string globalStr = ""; 

list<string> LinkedListGlobal; 

bool rentRetCheck = false; 

int numOfAdd = 0; 

 

// Customer IDs will be organized into a list 

list<string> customerList() { 

list<string> customerL; 

string holder = ""; 

string cIdS = "Customer ID:"; 

ifstream customerF("CustomerFile.txt"); 

while (getline(customerF, holder)) { 

if (cIdS.compare(holder.substr(0, 12)) == 0) { 

string tmp = holder.substr(13, 3); 

int tmpI = stoi(tmp); 

customerL.push_back(to_string(tmpI)); 

} 

} 

return customerL; 

} 

 

// Function that changes the value of a movie's total amount of stored copies,  

// in the event that it is rented or returned by a customer. 

void movieCopyAmount(int mId, int cId, bool rent, bool ret) { 

string categories[4] = { "Movie Title\t","Genre\t\t","Production\t","Number of Copies" }; 

string tmpData = ""; 

int mIdIndexCounter = 0; 

int inCounter = 0; 

 

list<list<string>> listConverted; 

list<string> tmpL; 

int itemCount = -1; 

for (auto i = LinkedListGlobal.begin(); i != LinkedListGlobal.end(); i++) { 

if (((*i).substr(0, 10)).compare("Movie ID: ") == 0) { 

itemCount = 0; 

continue; 

} 

if (itemCount > -1 && itemCount < 4) { 

tmpL.push_back(*i); 

itemCount++; 

continue; 

} 

if (itemCount >= 4) { 

listConverted.push_back(tmpL); 

tmpL.clear(); 

itemCount = -1; 

} 

} 

 

list<list<string>> allData = listConverted; 

LinkedListGlobal.clear(); 

 

// 1 - Show the details of the selected Movie ID 

// 2 - Update the whole file with decremented copies value 

for (auto i = allData.begin(); i != allData.end(); i++) { 

 

tmpData += "Movie ID: " + to_string(mIdIndexCounter) + '\n'; 

LinkedListGlobal.push_back("Movie ID: " + to_string(mIdIndexCounter)); 

for (auto g = i->begin(); g != i->end(); g++) { 

 

if (mIdIndexCounter == mId) { 

if (inCounter == 3) { 

int oneVal = -1; 

int cpCount = stoi(*g); 

if (ret == true) { 

oneVal = 1; 

} 

cpCount += oneVal; 

tmpData += to_string(cpCount) + '\n'; 

LinkedListGlobal.push_back(to_string(cpCount)); 

cout << categories[inCounter] << "\t\t:\t\t" << cpCount << endl; 

} 

else { 

tmpData += *g + "\n"; 

LinkedListGlobal.push_back(*g); 

cout << categories[inCounter] << "\t\t:\t\t" << *g << endl; 

} 

} 

else { 

tmpData += *g + "\n"; 

LinkedListGlobal.push_back(*g); 

} 

inCounter++; 

} 

tmpData += '\n'; 

LinkedListGlobal.push_back("\n"); 

mIdIndexCounter++; 

inCounter = 0; 

} 

cout << endl; 

cout << "===============================" << endl; 

 

ofstream movieData("MovieInfo.txt"); 

movieData << tmpData; 

movieData.close(); 

 

// Updates CustomerRentInfo.txt 

allCustomerRent(rent, ret, to_string(cId), to_string(mId)); 

} 

 

// Retrieves customer info and change the copy number when movie is rented/returned. 

stack<string> allCustomerRent(bool rent, bool ret, string cID, string mID) { 

 

list<string> customerRentConverted; 

stack<string> customerStackF; 

stack<string> customerStack; 

stack<string> customerStackTmp; 

string holder = ""; 

string cIdS = "Customer ID: "; 

string mIdS = "Movie ID: "; 

ifstream customerRentF("CustomerRentInfo.txt"); 

 

while (getline(customerRentF, holder)) { 

if (cIdS.compare(holder.substr(0, 13)) == 0) { 

customerRentConverted.push_back(holder.substr(13, holder.size() - 13)); 

customerStackTmp.push(holder.substr(13, holder.size() - 13)); 

} 

if (mIdS.compare(holder.substr(0, 10)) == 0) { 

customerRentConverted.push_back(holder.substr(10, holder.size() - 10)); 

customerStackTmp.push(holder.substr(10, holder.size() - 10)); 

} 

} 

customerRentF.close(); 

 

// Rearrange the customerstacktmp to get the original formatting from CustomerRentInfo.txt 

while (!customerStackTmp.empty()) { 

customerStack.push(customerStackTmp.top()); 

customerStackF.push(customerStackTmp.top()); 

customerStackTmp.pop(); 

} 

 

int counter = 0; 

bool customerDetectRet = false; 

bool customerDetectRent = false; 

bool hasRun = false; 

bool notInclude = false; 

string cIDTmp = ""; 

string customerString = ""; 

 

// STACK : Loops into the customer rent list to identify which copy to decrease or increase by 1 

while (!customerStack.empty()) { 

counter++; 

if (counter % 2 != 0) { 

if (cID.compare(customerStack.top()) == 0) { 

if (ret == true) { customerDetectRet = true; } 

else { customerString += cIdS + customerStack.top() + '\n'; } 

cIDTmp = cID; 

} 

else if (cID.compare(customerStack.top()) != 0) { 

customerString += cIdS + customerStack.top() + '\n'; 

} 

} 

 

if (counter % 2 == 0) { 

int movieRented; 

if (customerDetectRet == true) { 

if (mID == customerStack.top() && hasRun == false) { 

customerDetectRet = false; 

hasRun = true; 

} 

else { 

customerString += cIdS + cIDTmp + "\n" + mIdS + customerStack.top() + '\n'; 

customerDetectRet = false; 

} 

} 

else { 

customerString += mIdS + customerStack.top() + '\n'; 

} 

} 

customerStack.pop(); 

} 

 

if (rent == true) { 

customerString += cIdS + cID + '\n' + mIdS + mID + '\n'; 

} 

 

ofstream customerRentFile("CustomerRentInfo.txt"); 

customerRentFile << customerString << endl; 

customerRentFile.close(); 

return customerStackF; 

} 

 

public: 

CustomerInfo cI; 

 

// Retrieves data from MovieInfo.txt and inserts it to the linked list  

// so that it can be utilized by other functions. 

list<list<string>> allDataMovieLink() { 

string holder = ""; 

// Start: Create a link list to store the info from movie 

// Make it a 2D array for every ID 

list<list<string>> allData; 

list<string> oneData; 

ifstream movieData("MovieInfo.txt"); 

int iterator = 0; 

while (getline(movieData, holder)) { 

// Delete the items from oneData when iterator == 0 

if (iterator == 0) { 

oneData.clear(); 

} 

// Check if this is a new movie 

string strV("Movie ID: "); 

if (strV.compare(holder.substr(0, 10)) == 0) { 

iterator = 4; 

continue; 

} 

if (iterator > 0) { 

// Add the holder data in oneData 

oneData.push_back(holder); 

iterator--; 

if (iterator == 0) { 

// add oneData to allData 

allData.push_back(oneData); 

} 

} 

} 

movieData.close(); 

return allData; 

// END 

} 

 

// Constructor 

Movie() { 

// START: Check if the movie information file exsits 

cI.customerDefaultFile(); 

bool isFirstRun = false; 

ifstream fileVid("MovieInfo.txt"); 

 

if (fileVid) { 

// If movie informaton file already exists 

} 

else { 

isFirstRun = true; 

} 

fileVid.close(); 

// END 

 

string movieTitles[25] = { "Kuwaresma", "Ma", "The Exorcist", "The Conjuring", "The 8th Ngiht", 

"Love Actually", "Paper Towns", "The Fault in Ours Stars", "The Notebook", "A Star is Born", 

"Martian", "Interstellar", "Lightyear", "Gravity", "Wall-E", 

"Army of the Dead", "Black Panther", "Emoji Movie", "The Avengers", "The Suicide Squad", 

"The Upside", "Get Hard", "Fatherhood", "Click", "Central Intelligence", }; 

string movieGenres[5] = { "Horror", "Romance", "Sci-fi", "Action", "Comedy" }; 

string movieProductions[25] = { "Haunted Movies, Stage 6 Films, Alliance Films, IM Global", "Alliance Films, Automatik Blumhouse Productions, IM Global", "Hoya Productions", "New Line Cinema", "Gom Pictures, Gogo Studio", 

"Studio Canal, Working Title Films, DNA Films", "Marc Platt Productions", "Fox 2000 Pictures", "Gran Via", "Metro-Goldwyn-Mayer", 

"20th Century Studios", "Paramount Pictures", "20th Century Studios", "Warner Bros. Pictures", "Pixar and Walt Disney Pictures", 

"The Stone Quarry", "Marvel Studios", "20th Century Studios", "Metro-Goldwyn-Mayer", "DC Comics", 

"Universal Pictures", "Columbia Pictures", "Alphaville Films", "Paramount Pictures", "Working Title Films, StudioCanal, Film4 Productions" }; 

int movieCount = 0; 

int genreCount = 0; 

 

if (isFirstRun == true) { 

ofstream fileVidO("MovieInfo.txt"); 

// Sets up the default 25 movies [Horror, Romance, Sci-fi, Action, Comedy] with 100 default copies. 

 

for (int h = 0; h < movieGenres->length() - 1; h++) { 

for (int i = 0; i < movieTitles->length(); i++) { 

if (genreCount < 5) { 

fileVidO << "Movie ID: " << movieCount << endl; 

fileVidO << movieTitles[movieCount] << endl; 

fileVidO << movieGenres[h] << endl; 

fileVidO << movieProductions[movieCount] << endl; 

fileVidO << 100 << endl; 

fileVidO << endl; 

 

genreCount++; 

movieCount++; 

} 

} 

genreCount = 0; 

} 

fileVidO.close(); 

} 

 

ifstream fileVid2("MovieInfo.txt"); 

string holder; 

while (getline(fileVid2, holder)) { 

LinkedListGlobal.push_back(holder); 

} 

fileVid2.close(); 

movie_id = 24; 

} 

 

// Option 1 - INSERT NEW MOVIE INTO THE LIST 

void movieInsert() { 

 

// User input for the vid info 

cout << "Enter movie title: "; 

getline(cin, movieTitle); 

cout << "Enter movie genre: "; 

getline(cin, genre); 

 

cout << "Enter production: "; 

getline(cin, production); 

 

cout << "Enter number of copies: "; 

string strCopies; 

getline(cin, strCopies); 

numberOfCopies = stoi(strCopies); 

//END 

 

string holder = ""; 

// Checks the last movie ID and append one to it. Use the new Movie ID (x) when adding new item 

ifstream fileVid("MovieInfo.txt"); 

int x = -1; 

while (getline(fileVid, holder)) { 

string strV("Movie ID: "); 

if (strV.compare(holder.substr(0, 10)) == 0) { 

x = stoi(holder.substr(10, (holder.size() - 10))); 

} 

} 

x++; 

movie_id = x + numOfAdd; 

fileVid.close(); 

 

// Append the info of the movie in the txt file 

LinkedListGlobal.push_back("Movie ID: " + to_string(movie_id)); 

LinkedListGlobal.push_back(movieTitle); 

LinkedListGlobal.push_back(genre); 

LinkedListGlobal.push_back(production); 

LinkedListGlobal.push_back(to_string(numberOfCopies)); 

LinkedListGlobal.push_back("\n"); 

numOfAdd++; 

 

system("cls"); 

return; 

} 

 

// Option 2 - RENT A MOVIE FROM THE LIST 

void movieRent() { 

string holder = ""; 

rentRetCheck = true; 

bool rentDone = false; 

char userInput = 'y'; 

int cId = 0; 

int mId = 0; 

 

string categories[4] = { "Movie Title\t","Genre\t\t","Production\t","Number of Copies" }; 

 

while (rentDone == false) { 

int copiesLineNum = 0; 

if (userInput == 'y') { 

ifstream customerFileR("CustomerRentInfo.txt"); 

bool fileExist = false; 

if (!customerFileR) { 

ofstream customerFile("CustomerRentInfo.txt"); 

} 

customerFileR.close(); 

 

cout << "Enter Customer ID: "; 

cin >> cId; 

 

// Show the details of the customer 

cI.customerSearchDetails(cId, true); 

 

 

// Function that checks if a customer id and Movie ID exist in CustomerRentInfo.txt 

string sCId = to_string(cId); 

bool customerExist = false; 

list<string> customerL = customerList(); 

int customerCount = 0; 

 

// Loop to the customer rent file list to determine if customer or cid exist 

for (auto i = customerL.begin(); i != customerL.end(); i++) { 

if (sCId.compare(*i) == 0) { 

customerExist = true; 

} 

} 

 

if (customerExist == false) { 

cout << "====================================" << endl; 

cout << "Customer is not found." << endl; 

cout << "====================================\n" << endl; 

return; 

} 

 

asciiRentMovie(); 

cout << "Enter Movie ID: "; 

cin >> mId; 

 

if (mId > movie_id) { 

cout << "=================================" << endl; 

cout << "There are no movies with this ID" << endl; 

cout << "=================================\n" << endl; 

return; 

} 

 

// Decrement one to copy number from a selected mId 

movieCopyAmount(mId, cId, true, false); 

} 

else { 

// Stop the rent vid function 

return; 

} 

cout << "Rent another movie? (Y/N)\n"; 

cin >> userInput; 

system("cls"); 

asciiRentMovie(); 

} 

return; 

} 

 

// Option 3 - RETURN A MOVIE 

void movieReturn() { 

rentRetCheck = true; 

bool retDone = false; 

char userInput = 'y'; 

int cId = 0; 

int mId = 0; 

 

string categories[4] = { "Movie Title\t","Genre\t\t","Production\t","Number of Copies" }; 

 

while (retDone == false) { 

int copiesLineNum = 0; 

if (userInput == 'y') { 

ifstream customerFileR("CustomerRentInfo.txt"); 

bool fileExist = false; 

if (!customerFileR) { 

ofstream customerFile("CustomerRentInfo.txt"); 

} 

customerFileR.close(); 

 

cout << "Enter Customer ID: "; 

cin >> cId; 

// Displays customer details 

cI.customerSearchDetails(cId, false); 

 

if (cI.customerExist() == false) { 

cout << "You have no movies to return." << endl; 

cI.customerInfoDelete(cId); 

return; 

} 

 

asciiReturnMovie(); 

cout << "Enter Movie ID: "; 

cin >> mId; 

cout << endl; 

 

// START ...  a function that checks if a customer id and Movie ID exist in the cursomter rent file 

string sCId = to_string(cId); 

string sVId = to_string(mId); 

bool customerExist = false; 

bool customerMovieExist = false; 

stack<string> customerRentList = allCustomerRent(false, false, sCId, sVId); 

int customerCount = 0; 

 

// Loops to the customer rent file list to determine if mId and cId exist together 

while (!customerRentList.empty()) { 

string tmp = customerRentList.top(); 

if (customerCount == 2) { customerCount = 0; } 

if ((sCId.compare(tmp) == 0) && (customerCount == 0)) { 

customerExist = true; 

} 

else if ((sVId.compare(tmp) == 0) && (customerExist == true)) { 

cout << tmp << endl; 

customerMovieExist = true; 

customerCount = 0; 

break; 

} 

customerCount++; 

customerRentList.pop(); 

} 

 

if (customerMovieExist == false) { 

cout << "You have no more movies to return. Your data will be deleted..." << endl; 

cI.customerInfoDelete(cId); 

return; 

} 

//END 

 

 

 

// ALGORITHM 1 - Increment one to copy number from a selected mId 

movieCopyAmount(mId, cId, false, true); 

} 

else { 

// Stop the rent vid function 

return; 

} 

cout << "Return another movie? (Y/N)\n"; 

cin >> userInput; 

system("cls"); 

asciiReturnMovie(); 

} 

return; 

} 

 

// Option 4 - SEARCH FOR SPECIFIC MOVIE DETAILS 

void movieDetails() { 

asciiSearchMovie(); 

bool movieDetails = false; 

char userInput = 'y'; 

int cId = 0; 

int mId = 0; 

string holder = ""; 

int x = 0; 

list<string> vidInfoCategory({ "Movie Title\t","Genre\t\t","Production\t","Number of Copies" }); 

 

holder = ""; 

while (movieDetails == false) { 

int copiesLineNum = 0; 

if (userInput == 'y') { 

cout << "Enter Movie ID: "; 

cin >> mId; 

 

// START:  Show the selected Movie to rent 

list<list<string>> allData = allDataMovieLink(); 

list<string> holderList; 

// Include the newly added Movie 

cout << "=============================================\n" << endl; 

 

// Create a function that can detect all Movie IDs and show the details 

int detCount = 0; 

bool found = false; 

for (auto i = LinkedListGlobal.begin(); i != LinkedListGlobal.end(); i++) { 

 

string tmp = "Movie ID: "; 

string val = *i; 

 

if ((tmp).compare(val.substr(0, 10)) == 0) { 

int tmpId = stoi(val.substr(10, val.size() - 10)); 

if ((to_string(mId)).compare(to_string(tmpId)) == 0) { 

found = true; 

cout << tmp << tmpId << endl; 

continue; 

} 

} 

 

if (detCount < 4 && found == true) { 

auto it = next(vidInfoCategory.begin(), detCount); 

cout << *it << "\t:\t" << *i << endl; 

detCount++; 

} 

if (detCount == 4) { break; } 

} 

cout << "\n=============================================\n" << endl; 

// END 

} 

else { 

// Stop the return vid function 

return; 

} 

bool correctInput = false; 

cout << "Look for another movie? (Y/N)\n"; 

cin >> userInput; 

system("cls"); 

asciiSearchMovie(); 

} 

return; 

} 

 

 

// Option 5 - DISPLAY THE LIST OF MOVIES 

void movieDisplayList() { 

char userInput = 'y'; 

bool isDone = false; 

list<string> vidInfoCategory({ "Movie Title\t","Genre\t\t","Production\t","Number of Copies" }); 

list<list<string>> allData = allDataMovieLink(); 

 

// Displays all the movie details 

while (isDone == false) { 

if (userInput == 'y') { 

int categoryCounter = 0; 

int idCounter = 0; 

idCounter = 0; 

categoryCounter = -1; 

 

// Read all the movie items from the list 

for (auto k = LinkedListGlobal.begin(); k != LinkedListGlobal.end(); k++) { 

if (categoryCounter == 4) { 

categoryCounter = -1; 

cout << endl; 

continue; 

} 

if (categoryCounter > -1) { 

auto it = next(vidInfoCategory.begin(), categoryCounter); 

cout << *it << "\t\t: " << *k; 

cout << endl; 

} 

else { 

cout << *k; 

cout << endl; 

} 

categoryCounter++; 

} 

} 

else { 

return; 

} 

cout << "Look for another movie? (Y/N)\n"; 

cin >> userInput; 

system("cls"); 

asciiMoviesAvailable(); 

} 

return; 

} 

 

// Option 6 - CHECK MOVIE AVAILABILITY 

bool movieStatus() { 

bool isExist = false; 

bool checkDone = false; 

char userInput = 'y'; 

int cId = 0; 

int mId = 0; 

list<string> vidInfoCategory({ "Movie Title\t","Genre\t\t","Production\t","Number of Copies" }); 

 

while (checkDone == false) { 

int copiesLineNum = 0; 

if (userInput == 'y') { 

// Displays details of the customer 

 

cout << "Enter Movie ID: "; 

cin >> mId; 

 

// START: show the selected Movie to rent 

list<list<string>> allData = allDataMovieLink(); 

 

// Check if the mId is not of bounds 

if (allData.size() <= mId || mId < 0) { 

cout << "===============================\n" << endl; 

cout << "The movie does not exist.\n" << endl; 

cout << "===============================\n" << endl; 

cout << "Look for another movie? (Y/N) \n"; 

cin >> userInput; 

continue; 

} 

 

//Show the details before checking its availability 

auto it1 = next(allData.begin(), mId); 

 

int categoryCounter = 0; 

cout << "===============================\n" << endl; 

cout << "Movie ID: " << mId << endl << endl; 

for (auto i = it1->begin(); i != it1->end(); i++) { 

auto it1 = next(vidInfoCategory.begin(), categoryCounter); 

cout << *it1 << " \t\t :"; 

cout << *i << endl; 

categoryCounter++; 

} 

//END 

 

// Check if mId is available  

// Possible results: 

// [ copies=0 -> Not Available] 

// [ copies>0 -> Available] 

// [ No existing ID ] 

int mIdIndexCounter = 0; 

int inCounter = 0; 

 

// Loops through the allData link list  

for (auto i = allData.begin(); i != allData.end(); i++) { 

for (auto g = i->begin(); g != i->end(); g++) { 

if (mIdIndexCounter == mId) { 

if (inCounter == 3) { 

// Detect if copies are greater than 0  

int copies = stoi(*g); 

if (copies > 0) { 

isExist = true; 

break; 

} 

else { 

isExist = false; 

break; 

} 

} 

} 

inCounter++; 

} 

mIdIndexCounter++; 

inCounter = 0; 

} 

// END 

} 

else { 

// Stop the check movie function 

break; 

} 

 

if (isExist == true) { 

cout << "\nStatus: AVAILABLE" << endl; 

} 

if (isExist == false) { 

cout << "\nStatus: NOT AVAILABLE" << endl; 

} 

 

cout << "\n===============================\n" << endl; 

 

cout << "Look for another movie? (Y/N) \n"; 

cin >> userInput; 

system("cls"); 

asciiMovieStatus(); 

} 

return isExist; 

} 

 

// Option 7 - CUSTOMER MAINTENANCE 

void customerMaintenance() { 

cI.customerMenu(); 

} 

void CallCustomerDetails() { 

cI.customerSearchDetails(); 

} 

 

 

// Option 8 - LEAVE THE PROGRAM 

void save() { 

// Insert the changes from a TMPSTRING to MovieInfo.txt and CustomerRentInfo.txt 

ofstream fileVidO("MovieInfo.txt"); 

for (auto i = LinkedListGlobal.begin(); i != LinkedListGlobal.end(); i++) { 

if ((*i).compare("\n") == 0) { 

fileVidO << *i; 

continue; 

} 

fileVidO << *i << endl; 

} 

fileVidO.close(); 

system("cls"); 

cout << "\n\n\n" << R"( 

                                     _   _                 _                        _  

                                    | | | |               | |                      | | 

                                    | |_| |__   __ _ _ __ | | __  _   _  ___  _   _| | 

                                    | __| '_ \ / _` | '_ \| |/ / | | | |/ _ \| | | | | 

                                    | |_| | | | (_| | | | |   <  | |_| | (_) | |_| |_| 

                                     \__|_| |_|\__,_|_| |_|_|\_\  \__, |\___/ \__,_(_) 

                                                                   __/ |               

                                                                  |___/  

 

                                 [ Program has been terminated and files has been saved. ] 

          FINALS Program for CCS0015L 

                                                by Stop the Car Group 

                                   (Adrian Navarro, Janna Rane Rosendo, Giro Manzano)  

 

)" << endl << endl; 

} 

 

 

 

 

 

// The following void functions are just for presentation. 

void asciiInsertMovie() { 

cout << R"( 

  

======================================================================================================================== 

 

                     .-..-. .-. .----..----..----.  .---.    .-.   .-. .----. .-. .-..-..----. 

                     | ||  `| |{ {__  | {_  | {}  }{_   _}   |  `.'  |/  {}  \| | | || || {_   

                     | || |\  |.-._} }| {__ | .-. \  | |     | |\ /| |\      /\ \_/ /| || {__  

                     `-'`-' `-'`----' `----'`-' `-'  `-'     `-' ` `-' `----'  `---' `-'`----' 

 

======================================================================================================================== 

 

)" << endl; 

} 

 

void asciiRentMovie() { 

cout << R"( 

  

======================================================================================================================== 

 

                    .----. .----..-. .-. .---.      .--.     .-.   .-. .----. .-. .-..-..----. 

                    | {}  }| {_  |  `| |{_   _}    / {} \    |  `.'  |/  {}  \| | | || || {_   

                    | .-. \| {__ | |\  |  | |     /  /\  \   | |\ /| |\      /\ \_/ /| || {__  

                    `-' `-'`----'`-' `-'  `-'     `-'  `-'   `-' ` `-' `----'  `---' `-'`----' 

 

======================================================================================================================== 

 

)" << endl; 

} 

 

void asciiReturnMovie() { 

cout << R"( 

  

======================================================================================================================== 

 

                  .----. .----..---. .-. .-..----. .-. .-.     .--.     .-.   .-. .----. .-. .-..-..----. 

                  | {}  }| {_ {_   _}| { } || {}  }|  `| |    / {} \    |  `.'  |/  {}  \| | | || || {_   
| .-. \| {__  | |  | {_} || .-. \| |\  |   /  /\  \   | |\ /| |\      /\ \_/ /| || {__  

                  `-' `-'`----' `-'  `-----'`-' `-'`-' `-'   `-'  `-'   `-' ` `-' `----'  `---' `-'`----' 

 

======================================================================================================================== 

 

)" << endl; 

} 

 

void asciiSearchMovie() { 

cout << R"( 

  

======================================================================================================================== 

 

                    .----..----.  .--.  .----.  .---. .-. .-.   .-.   .-. .----. .-. .-..-..----. 

                   { {__  | {_   / {} \ | {}  }/  ___}| {_} |   |  `.'  |/  {}  \| | | || || {_   

                   .-._} }| {__ /  /\  \| .-. \\     }| { } |   | |\ /| |\      /\ \_/ /| || {__  

                   `----' `----'`-'  `-'`-' `-' `---' `-' `-'   `-' ` `-' `----'  `---' `-'`----' 

 

======================================================================================================================== 

 

)" << endl; 

} 

 

void asciiMoviesAvailable() { 

cout << R"( 

  

======================================================================================================================== 

 

       .-.   .-. .----. .-. .-..-..----. .----.     .--.  .-. .-.  .--.  .-..-.     .--.  .----. .-.   .----. 

       |  `.'  |/  {}  \| | | || || {_  { {__      / {} \ | | | | / {} \ | || |    / {} \ | {}  }| |   | {_   

       | |\ /| |\      /\ \_/ /| || {__ .-._} }   /  /\  \\ \_/ //  /\  \| || `--./  /\  \| {}  }| `--.| {__  

       `-' ` `-' `----'  `---' `-'`----'`----'    `-'  `-' `---' `-'  `-'`-'`----'`-'  `-'`----' `----'`----' 

 

======================================================================================================================== 

 

)" << endl; 

} 

 

void asciiMovieStatus() { 

cout << R"( 

  

======================================================================================================================== 

 

                .-.   .-. .----. .-. .-..-..----.    .----..---.  .--.  .---. .-. .-. .----. 

                |  `.'  |/  {}  \| | | || || {_     { {__ {_   _}/ {} \{_   _}| { } |{ {__   

                | |\ /| |\      /\ \_/ /| || {__    .-._} } | | /  /\  \ | |  | {_} |.-._} } 

                `-' ` `-' `----'  `---' `-'`----'   `----'  `-' `-'  `-' `-'  `-----'`----'  

 
======================================================================================================================== 

 

)" << endl; 

} 

}; 
