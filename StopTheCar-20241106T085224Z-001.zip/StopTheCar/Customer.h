CUSTOMER.H 

#pragma once 

#include <string> 

#include <list> 

using namespace std; 

class CustomerInfo { 

  

private: 

  	int cID = 0; 

  	int newadd = 0; 

  	int namecounter = 0; 

  	string name; 

  	string address; 

  	list<string>LinkedListGlobal; 

  

public: 

  	int customerToDel = -1; 

  

  	struct Customer { 

        	int CustomerId; 

        	string CustomerName, CustomerAddress; 

        	Customer* next; 

  	}; 

  

  	typedef CustomerInfo::Customer* Customerptr; 

  	Customerptr start; 

  	Customerptr nodeptr; 

  	Customerptr prevptr; 

  	// Constructor 

  	CustomerInfo() { 

        	start = NULL; 

        	nodeptr = NULL; 

        	prevptr = NULL; 

  	} 

  

  	void customerDefaultFile(); 

  	void customerDefaultInsert(int id, string name, string address); 

  	void customerInfoAdd(); 

  	void customerInfoDelete(int cID); 

  	void customerInfoUpdate(); 

  	void customerDisplayList(); 

  	void customerSearchDetails(int cIdLocal, bool isRent); 

  	void customerSearchDetails(); 

  	bool customerExist(); 

  	void customerMenu(); 

  	void customerWriteRecord(int id, string name, string address); 

}; 