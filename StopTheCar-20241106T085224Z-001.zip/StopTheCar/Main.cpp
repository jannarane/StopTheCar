#include <iostream> 

#include "Movie.h" 

#include <string> 

#include <string.h> 

#include <fstream> 

#include "Customer.h" 

using namespace std; 

  

void splashscreen() 

{ 

  	cout << "\n\n\n\n\n\n\n\n" << R"( 

  

               	.----..---.  .----. .----. 	.---. .-. .-..----.	.---.   .--.  .----. 

              	{ {__ {_   _}/  {}  \| {}  }   {_   _}| {_} || {_ 	/  ___} / {} \ | {}  } 

              	.-._} } | |  \      /| .--'  	| |  | { } || {__	\     }/  /\  \| .-. \ 

              	`----'  `-'   `----' `-'     	`-'  `-' `-'`----'	`---' `-'  `-'`-' `-' 

                                           [  M O V I E	C E N T E R  ] 

  

                                          Founded in 2022 by Adrian Navarro,          	 

                                     	Janna Rane Rosendo and Giro Manzano  

                      	 

  

                                               Press enter to proceed 

  	)" << endl; 

  	getchar(); 

} 

  

void menu() { 

  	Movie m; 

  	bool notDone = false; 

  	while (notDone == false) { 

        	system("cls"); 

        	cout << R"( 

  

======================================================================================================================== 

  

               	.----..---.  .----. .----. 	.---. .-. .-..----.	.---.   .--.  .----. 

              	{ {__ {_   _}/  {}  \| {}  }   {_   _}| {_} || {_ 	/  ___} / {} \ | {}  } 

              	.-._} } | |  \      /| .--'  	| |  | { } || {__	\     }/  /\  \| .-. \ 

              	`----'  `-'   `----' `-'     	`-'  `-' `-'`----'	`---' `-'  `-'`-' `-' 

      	                                 [  M O V I E    C E N T E R  ]             	 

  

                                       -------------------------------------- 

  

                                   	[1] Insert new movie into the list 

                	                   [2] Rent a movie from the list 

                                   	[3] Return a movie 

                                   	[4] Search for specific movie details 

                                   	[5] Display the list of movies 

                                   	[6] Check movie availability
 
                                   	[7] Customer maintenance 

                                   	[8] Leave the program 

  

                                       -------------------------------------- 

  

======================================================================================================================== 

  

  	)" << endl; 

        	int choice; 

        	cin >> choice; 

        	string x; 

        	getline(cin, x); 

  

        	switch (choice) { 

        	case 1: 

              	system("cls"); 

              	m.asciiInsertMovie(); 

              	m.movieInsert(); 

              	break; 

        	case 2: 

              	system("cls"); 

              	m.asciiRentMovie(); 

              	m.movieRent(); 

              	break; 

        	case 3: 

              	system("cls"); 

              	m.asciiReturnMovie(); 

              	m.movieReturn(); 

              	break; 

        	case 4: 

              	system("cls"); 

              	m.movieDetails(); 

              	break; 

        	case 5: 

              	system("cls"); 

              	m.asciiMoviesAvailable(); 

              	m.movieDisplayList(); 

              	break; 

        	case 6: 

              	system("cls"); 

              	m.asciiMovieStatus(); 

              	m.movieStatus(); 

              	break; 

        	case 7: 

              	m.customerMaintenance(); 

              	continue; 

        	case 8: 

              	notDone = true; 

              	m.save(); 

              	 

              	break; 

        	} 

  	} 

} 

  

int main() { 

  	splashscreen(); 

  	menu(); 

  	return 1; 

} 