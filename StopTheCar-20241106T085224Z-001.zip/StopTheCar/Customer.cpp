#include <iostream> 

#include <set> 

#include <iomanip> 

#include <fstream> 

#include <string> 

#include <list> 

#include "Movie.h" 

#include "Customer.h" 

  

using namespace std; 

fstream file; 

fstream dfile; 

ofstream temptfile; 

ofstream temp; 

ifstream myfile; 

typedef CustomerInfo::Customer* Customerptr; 

Customerptr started; 

static bool isExist = false; 

  

// Displays the customer maintenance menu (option 7) 

void CustomerInfo::customerMenu() { 

  	system("CLS"); 

  	int a, cId; 

  	bool dontExit = true; 

  	do { 

        	int a; 

        	cout << R"( 

  

  

======================================================================================================================== 

  

               	.----..---.  .----. .----. 	.---. .-. .-..----.	.---.   .--.  .----. 

              	{ {__ {_   _}/  {}  \| {}  }   {_   _}| {_} || {_ 	/  ___} / {} \ | {}  } 

              	.-._} } | |  \      /| .--'  	| |  | { } || {__	\     }/  /\  \| .-. \ 

              	`----'  `-'   `----' `-'     	`-'  `-' `-'`----'	`---' `-'  `-'`-' `-' 
 [  M O V I E    C E N T E R  ]             	 

  

                                                  C U S T O M E R 

                                               M A I N T E N A N C E 

  

                                  	 -------------------------------------- 

  

                                   	[1] Add customer information 

                                   	[2] Search customer information 

                                   	[3] Display all customers 

       	                            [4] Display movies rented by customer 

                                   	[5] Return to main menu 

  

                                       -------------------------------------- 

  

======================================================================================================================== 

  

  	)" << endl; 

        	cin >> a; 

  

        	// The algorithm will scan the user input and execute the matching function. 

        	switch (a) { 

        	case 1: 

              	system("cls"); 

              	cout << R"( 

  

======================================================================================================================== 

  

   	.--.  .----. .----. 	.---. .-. .-. .----..---.  .----. .-.   .-..----..----.	.-..-. .-..----..----. 

  	/ {} \ | {}  \| {}  \   /  ___}| { } |{ {__ {_   _}/  {}  \|  `.'  || {_  | {}  }   | ||  `| || {_ /  {}  \ 

 	/  /\  \| 	/|     /   \ 	}| {_} |.-._} } | |  \      /| |\ /| || {__ | .-. \   | || |\  || |  \  	/ 

 	`-'  `-'`----' `----' 	`---' `-----'`----'  `-'   `----' `-' ` `-'`----'`-' `-'   `-'`-' `-'`-'   `----' 

  

======================================================================================================================== 

  

              	)" << endl; 

              	customerInfoAdd(); 

              	break; 

        	case 2: 

              	system("cls"); 

              	cout << R"( 

  

======================================================================================================================== 

  

    	.----..----.  .--.  .----.  .---. .-. .-.	.---. .-. .-. .----..---.  .----. .-.   .-..----..----. 

   	{ {__  | {_   / {} \ | {}  }/  ___}| {_} |   /  ___}| { } |{ {__ {_   _}/  {}  \|  `.'  || {_  | {}  } 

  	 .-._} }| {__ /  /\  \| .-. \\ 	}| { } |   \ 	}| {_} |.-._} } | |  \      /| |\ /| || {__ | .-. \ 

   	`----' `----'`-'  `-'`-' `-' `---' `-' `-'	`---' `-----'`----'  `-'   `----' `-' ` `-'`----'`-' `-' 

  
======================================================================================================================== 

  

              	)" << endl; 

              	customerSearchDetails(); 

              	break; 

        	case 3: 

              	system("cls"); 

              	cout << R"( 

  

======================================================================================================================== 

  

              	.---. .-. .-. .----..---.  .----. .-.   .-..----..----.	.-..-. .-..----..----. 

             	/  ___}| { } |{ {__ {_   _}/  {}  \|  `.'  || {_  | {}  }   | ||  `| || {_ /  {}  \ 

             	\ 	}| {_} |.-._} } | |  \      /| |\ /| || {__ | .-. \   | || |\  || |  \  	/ 

              	`---' `-----'`----'  `-'   `----' `-' ` `-'`----'`-' `-'   `-'`-' `-'`-'   `----' 

  

======================================================================================================================== 

  

              	)" << endl; 

              	customerDisplayList(); 

              	break; 

        	case 4: 

              	system("cls"); 

              	cout << R"( 

  

======================================================================================================================== 

  

              	.-.   .-. .----. .-. .-..-..----.   .----. .----..-. .-. .---. .----..----. 

              	|  `.'  |/  {}  \| | | || || {_ 	| {}  }| {_  |  `| |{_   _}| {_  | {}  \ 

              	| |\ /| |\  	/\ \_/ /| || {__	| .-. \| {__ | |\  |  | |  | {__ | 	/ 

              	`-' ` `-' `----'  `---' `-'`----'   `-' `-'`----'`-' `-'  `-'  `----'`----' 

  

======================================================================================================================== 

  

              	)" << endl; 

              	cout << "Enter Customer ID: "; 

              	cin >> cId; 

              	customerSearchDetails(cId, false); 

        	  	break; 

        	case 5: 

              	system("cls"); 

              	dontExit = false; 

              	break; 

        	default: 

              	system("cls"); 

              	cout << "Invalid input."; 

              	cin.ignore(); 

        	} 
} while (dontExit); 

  

} 

  

// Option 1 - ADD CUSTOMER INFORMATION 

// Function for allowing the user to add new customer information to the linked list. 

void CustomerInfo::customerInfoAdd() { 

  	srand(time(NULL) % 1000); 

  	bool counter = 0; 

  	Customerptr  newNode, nodeptr, prevptr; 

  	cin.ignore(); 

  	cout << "Enter your name: "; 

  	getline(cin, name); 

  	cout << "Enter your address: "; 

  	getline(cin, address); 

  	string holder = ""; 

  	int x = -1; 

  	system("cls"); 

  	while (getline(file, holder)) { 

        	string strV("Customer_id:"); 

        	if (strV.compare(holder.substr(0, 10)) == 0) { 

              	x = stoi(holder.substr(10, (holder.size() - 10))); 

        	} 

  	} 

  	x++; 

  	newadd++; 

  	cID = rand() % 1000; 

  	newNode = new Customer; 

  	newNode->CustomerId = cID; 

  	newNode->CustomerName = name; 

  	newNode->CustomerAddress = address; 

  	if (start == NULL) { 

        	start = newNode; 

        	newNode->next = NULL; 

        	customerWriteRecord(cID, name, address); 

  	} 

  	else { 

        	nodeptr = start; 

        	prevptr = NULL; 

        	if (prevptr == NULL) { 

              	start = newNode; 

              	newNode->next = nodeptr; 

        	} 

        	else if (counter == 0) { 

              	prevptr->next = newNode; 

              	newNode->next = nodeptr; 

        	} 

        	customerWriteRecord(cID, name, address); 

  	} 

  	// Accesses the customer ID in the movie.h 

  	LinkedListGlobal.push_back("CustomerID:\t" + to_string(cID) + '\n'); 

  	LinkedListGlobal.push_back("Name:\t\t" + name + '\n'); 
LinkedListGlobal.push_back("Address:\t" + address + '\n' + '\n'); 

} 

  

// Option 2 - SEARCH CUSTOMER INFORMATION 

// Allows the user to search for a specific customer’s information thru its customer ID 

void CustomerInfo::customerSearchDetails() { 

  	Customerptr nodePtr; 

  	int cId; 

  	int counter = 0; 

  	if (start == NULL) { 

        	cout << "The list is empty" << endl; 

  	} 

  	else { 

        	nodePtr = start; 

        	 

        	cout << "Enter Customer ID: "; 

        	cin >> cId; 

        	cout << endl; 

  

        	while (nodePtr != NULL && cId != nodePtr->CustomerId) { 

              	nodePtr = nodePtr->next; 

        	} 

        	if (nodePtr != NULL) { 

              	 

              	cout << "Customer ID:\t" << nodePtr->CustomerId << endl; 

              	cout << "Name:\t\t" << nodePtr->CustomerName << endl; 

              	cout << "Address:\t" << nodePtr->CustomerAddress << endl << endl; 

              	cout << "===============================\n" << endl; 

        	} 

        	else { 

              	cout << "The ID Number does not exist." << endl; 

        	} 

  	} 

  	cout << "Press any key to continue..."; 

  	cin.ignore(); 

  	cin.get(); 

  	system("cls"); 

} 

  

// Option 3 - DISPLAY ALL CUSTOMERS 

// Displays the list of all customers and the information about them. 

void CustomerInfo::customerDisplayList() { 

  	myfile.open("CustomerFile.txt"); 

  	string text; 

  	if (myfile.is_open()) { 

        	while (getline(myfile, text)) { 

              	cout << text << endl; 

        	} 

        	myfile.close(); 

        	cout << "===============================\n" << endl; 

  	} 

  	cout << "\nPress any key to continue...."; 
cin.ignore(); 

  	cin.get(); 

  	system("cls"); 

} 

  

// Option 4 - DISPLAY MOVIES RENTED BY CUSTOMER 

void CustomerInfo::customerSearchDetails(int cIdLocal, bool isRent) { 

  	Customerptr nodePtr; 

  	int counter = 0; 

  

  	if (start == NULL) { 

        	cout << "The list is empty." << endl; 

  	} 

  	else { 

        	nodePtr = start; 

        	int cId = cIdLocal; 

  

        	while (nodePtr != NULL && cId != nodePtr->CustomerId) { 

              	nodePtr = nodePtr->next; 

        	} 

        	if (nodePtr != NULL) { 

        	 

              	cout << "\nCustomer ID:\t" << nodePtr->CustomerId << endl; 

              	cout << "Name:\t\t" << nodePtr->CustomerName << endl; 

              	cout << "Address:\t" << nodePtr->CustomerAddress << endl << endl; 

        	} 

        	else { 

              	cout << "The ID Number does not exist." << endl; 

        	} 

  	} 

  

  	string cIdStr = to_string(cIdLocal); 

  

  	// Displays details of rented movies of a customer 

  	// Iterates on CustomerFile.txt and get the movie id 

  	// Once CID is matched, get the movie id and transfer it to the linked list. 

  	ifstream customerRentF("CustomerRentInfo.txt"); 

  	list<string> customerRentConverted; 

  	set<string> customerSet; 

  	int countOfCopy = 0; 

  	list<string> amountOfCopies; 

  	string holder; 

  	string cIdS = "Customer ID: "; 

  	string mIdS = "Movie ID: "; 

  

  	while (getline(customerRentF, holder)) { 

        	if (cIdS.compare(holder.substr(0, 13)) == 0 && cIdStr == holder.substr(13, holder.size() - 13)) { 

              	getline(customerRentF, holder); 

              	// Transfer the movie ID to an array 

              	customerSet.insert(holder.substr(10, holder.size() - 10)); 

              	amountOfCopies.push_back(holder.substr(10, holder.size() - 10)); 

        	} 
} 

  

  	for (auto i = customerSet.begin(); i != customerSet.end(); i++) { 

        	customerRentConverted.push_back(*i); 

  	} 

  	// Loop to MovieInfo.txt file and transfer it to the linked list. 

  	Movie m; 

  	list<list<string>> allData = m.allDataMovieLink(); 

  

  	if ((customerRentConverted.size() > 0)) { 

        	isExist = true; 

  	} 

  

  	// Loop on linked list then create and display the details for each movie id in the array 

  	counter = 0; 

  	int tracker = 0; 

  	bool found = false; 

  	bool hasContent = false; 

  	string categories[4] = { "Movie Title\t", "Genre\t\t", "Production\t", "Number of Copies", }; 

  	 

  	// Loop inside the recorded Movie ID of a customer's rented movies 

  	if (isExist == true) { cout << "===============================\n" << endl; } 

  

  	for (auto g = customerRentConverted.begin(); g != customerRentConverted.end(); g++) { 

        	// Show the details of specific movie 

        	int id = stoi(*g); 

        	for (auto i = allData.begin(); i != allData.end(); i++) { 

              	if (id == counter) { 

                    	cout << "Movie ID: " << id << endl; 

                    	// Info of the corresponding Movie ID 

                    	for (auto f = i->begin(); f != i->end(); f++) { 

                          	if (tracker > 1) { break; } 

                          	cout << categories[tracker] << "\t:\t" << *f << endl; 

                          	tracker++; 

                          	// Verifies if there is content found 

                          	if ((*f).compare("") != 0) { 

                                	hasContent = true; 

                          	} 

                    	} 

                    	// Determines the amount of copies a customer has 

                    	for (auto c = amountOfCopies.begin(); c != amountOfCopies.end(); c++) { 

  	                    	if ((to_string(id)).compare(*c) == 0) { 

                                	countOfCopy++; 

                          	} 

                    	} 

                    	cout << "Copies\t\t\t:\t" << countOfCopy << endl; 

                    	countOfCopy = 0; 

                    	tracker = 0; 

              	} 

              	counter++; 

        	} 

        	cout << endl; 
counter = 0; 

  	} 

  

  	// Determine if the user exists in CustomerFile.txt 

  	if (hasContent == false) { 

        	cout << "No records were found." << endl; 

        	isExist = false; 

        	cout << "Press any key to continue..."; 

        	cin.ignore(); 

        	cin.get(); 

        	system("cls"); 

        	return; 

  	} 

  

  	if (isExist == true) { cout << "\n===============================" << endl; } 

  	cout << "Press any key to continue..."; 

  	cin.ignore(); 

  	cin.get(); 

  	system("cls"); 

} 

  

// Deletes the customer data once they have returned all the videos they have rented. 

void CustomerInfo::customerInfoDelete(int cID) { 

  	Movie m; 

  	Customerptr searchptr; 

  	Customer* nodeptr; 

  	Customer* prevptr = start; 

  	system("cls"); 

  	int found = 0; 

  	int counter = 0; 

  	char ans = 'y'; 

  	if (start == NULL) { 

        	cout << "The list is empty." << endl; 

        	return; 

  	} 

  	else { 

        	searchptr = start; 

        	system("cls"); 

  

        	while (searchptr != NULL && cID != searchptr->CustomerId) { 

              	searchptr = searchptr->next; 

              	counter++; 

        	} 

        	if (ans == 'Y' || 'y') { 

              	if (counter == 0) { 

                    	nodeptr = start->next; 

                    	delete start; 

                    	start = nodeptr; 

                    	found = 1; 

              	} 

              	else { 

                    	if (counter != 0) { 
for (int i = 0; i < counter - 1; i++) { 

                                	prevptr = prevptr->next; 

                          	} 

                          	Customer* newnode = prevptr->next; 

                          	prevptr->next = newnode->next; 

                          	delete newnode; 

                    	} 

              	} 

        	} 

  	} 

  	m.asciiReturnMovie(); 

  	cout << "You have rented no movies. Your details will now be removed from the records." << endl; 

  	cout << "\nPress any key to continue...."; 

  	customerInfoUpdate(); 

  	cin.get(); 

} 

  

// Updates the information of the customer file when the customer returns all the movies rented. 

void CustomerInfo::customerInfoUpdate() { 

  	temptfile.open("temp.txt"); 

  	Customer* nodeptr = start; 

  	while (nodeptr != NULL) { 

        	temptfile << "Customer ID: " << nodeptr->CustomerId << endl; 

        	temptfile << "Name: " << nodeptr->CustomerName << endl; 

        	temptfile << "Address: " << nodeptr->CustomerAddress << endl << endl; \ 

              	nodeptr = nodeptr->next; 

  	} 

  	temptfile.close(); 

  	remove("CustomerFile.txt"); 

  	rename("temp.txt", "CustomerFile.txt"); 

} 

  

// Stores 10 pre-made customer information. 

void CustomerInfo::customerDefaultFile() { 

  	Customerptr  newNode, nodeptr, prevptr; 

  	Customerptr* root = NULL; 

  	bool isFirstRun = true; 

  	ifstream cDefaultFile("CustomerFile.txt"); 

  	int customercounter = 0; 

  	if (cDefaultFile) { 

        	return; 

  	} 

  	else { 

        	isFirstRun = true; 

  	} 

  	cDefaultFile.close(); 

  	if (isFirstRun = true) { 

        	srand(time(NULL)); 

        	ofstream CDFile("CustomerFile.txt"); 

  

        	int id[]{ 435, 123, 234, 353, 134, 164, 

                    	   467, 342, 634, 432 }; 
string name[]{ "Adrian Navarro", "Janna Rane Rosendo",  "Giro Manzano",  "Jane Ciego",  "Ricardo Milos", 

                                	 "Raymundo Dalisay", "Luzviminda Catiis", "Lorena Morgia", "Brenda Espineda", "Lucia Eresmas" }; 

        	string address[]{ "Plaridel, Bulacan", "Quezon City",  "Manila City",  "Makati City",  "Antipolo City", 

                                	 "Navotas City", "Pulilan, Bulacan", "Taguig City", "Angeles City", "Sorsogon City" }; 

  

        	int n = sizeof(name) / sizeof(name[0]); 

        	if (namecounter < 10) { 

              	for (int i = n - 1; i >= 0; i--) { 

                    	customerDefaultInsert(id[i], name[i], address[i]); 

                    	namecounter++; 

              	} 

        	} 

  

        	CDFile.close(); 

        	//looping for global link list push 

       

  	for (int i = 0; i < name->length(); i++) { 

              	if (customercounter < 10) { 

                    	LinkedListGlobal.push_back("CustomerID:\t" + to_string(id[customercounter]) + '\n'); 

                    	LinkedListGlobal.push_back("Name:\t\t" + name[customercounter] + '\n'); 

                    	LinkedListGlobal.push_back("Address:\t" + address[customercounter] + '\n' + '\n'); 

                    	customercounter++; 

              	} 

        	} 

  	} 

} 

  

// Inserts the 10 pre-made customer information from the customer default file 

// to the CustomerFile.txt file on the program’s first run. 

// If the program has been run before, it will no longer put additional information in the file. 

void CustomerInfo::customerDefaultInsert(int id, string name, string address) { 

  	Customerptr newNode; 

  	bool counter = 0; 

  	newNode = new Customer; 

  	newNode->CustomerId = id; 

  	newNode->CustomerName = name; 

  	newNode->CustomerAddress = address; 

  	if (start == NULL) { 

        	start = newNode; 

        	newNode->next = NULL; 

        	customerWriteRecord(id, name, address); 

  	} 

  	else { 

        	nodeptr = start; 

        	prevptr = NULL; 

        	if (prevptr == NULL) { 

              	start = newNode; 

              	newNode->next = nodeptr; 

        	} 

        	else if (counter == 0) { 

              	prevptr->next = newNode; 

              	newNode->next = nodeptr; 

} 

        	customerWriteRecord(id, name, address); 

  	} 

} 

  

// Retrieves input from customerInfoAdd and writes 

// all the input to the CustomerFile.txt file. 

void CustomerInfo::customerWriteRecord(int id, string name, string address) { 

  	file.open("CustomerFile.txt", ios::in | ios::app | ios::out); 

  	file << "\nCustomer ID: " << id << endl << "Name: " << name << endl << "Address: " 

        	<< address << "\n"; 

  	file.close(); 

} 

// Verifies if the matching customer ID exists in CustomerFile.txt 

bool::CustomerInfo::customerExist() { 

  	return isExist; 